# 💰 CashPilot Plugin — Assistant Financier Complet

Plugin Claude Cowork/Code pour gérer l'intégralité de votre gestion financière CashPilot directement depuis votre assistant IA.

## 🔌 Connexion

Ce plugin se connecte à **cashpilot.tech** via le serveur MCP intégré avec accès complet à toutes les fonctionnalités.

**Base de données Supabase**: `rfzvrezrcigzmldgvntz` (eu-central-1)  
**MCP Endpoint**: `https://cashpilot.tech/mcp`

---

## 📋 Commandes disponibles (`/cashpilot:`)

| Commande | Description |
|----------|-------------|
| `tableau-de-bord` | Vue d'ensemble KPIs, trésorerie, impayés |
| `creer-facture` | Créer une nouvelle facture |
| `creer-devis` | Créer un devis professionnel |
| `creer-client` | Enregistrer un nouveau client |
| `encaisser-paiement` | Enregistrer un paiement reçu |
| `relances-paiement` | Analyser les impayés et générer des relances |
| `rapport-financier` | Rapport mensuel/trimestriel/annuel |
| `analyse-ia` | Prévisions, anomalies, catégorisation IA |
| `rapprochement-bancaire` | Rapprocher transactions bancaires et factures |
| `bilan-comptable` | Balance de vérification et grand livre |
| `gestion-stock` | Inventaire, alertes stock, valorisation |
| `suivi-projets` | Avancement, heures, rentabilité projets |
| `fournisseurs` | Factures reçues, commandes, paiements |
| `export-comptable` | FEC, SAF-T, Factur-X |
| `scenario-financier` | Simulations et projections financières |
| `note-de-credit` | Créer un avoir/note de crédit |
| `bon-de-livraison` | Créer et suivre les livraisons |

---

## 🧠 Skills activées automatiquement

- **Comptabilité Belge** — Plan Comptable Belge, TVA, obligations légales
- **Facturation** — Règles de numérotation, mentions obligatoires, délais belges
- **Gestion de Trésorerie** — Flux, rapprochement, Open Banking
- **Analyse Financière** — KPIs, métriques, benchmarks
- **Stock & Services** — Produits, timesheets, projets
- **Clients & Fournisseurs** — Cycle complet achat/vente
- **IA CashPilot** — 8 Edge Functions IA disponibles

---

## 🗃️ Architecture de la base de données

50+ tables organisées par domaine:
- **Facturation**: invoices, invoice_items, quotes, credit_notes, delivery_notes, recurring_invoices
- **Paiements**: payments, payment_allocations, payment_reminder_rules
- **Comptabilité**: accounting_chart_of_accounts, accounting_entries, accounting_mappings, accounting_tax_rates
- **Stock**: products, product_categories, product_stock_history, stock_alerts, product_barcodes
- **Projets**: projects, tasks, subtasks, timesheets, services
- **Fournisseurs**: suppliers, supplier_invoices, supplier_orders, supplier_products, supplier_locations
- **Banque**: bank_connections, bank_transactions, bank_statements, bank_reconciliation_sessions
- **Scénarios**: financial_scenarios, scenario_assumptions, scenario_results, scenario_comparisons
- **CRM**: clients, receivables, payables, debt_payments
- **Système**: profiles, company, user_credits, api_keys, webhooks

---

## ⚡ Edge Functions disponibles

| Fonction | Usage |
|----------|-------|
| `extract-invoice` | Extraction IA des factures fournisseurs (PDF) |
| `ai-categorize` | Catégorisation automatique des dépenses |
| `ai-anomaly-detect` | Détection d'anomalies financières |
| `ai-forecast` | Prévisions de trésorerie |
| `ai-reminder-suggest` | Optimisation des relances |
| `ai-report` | Rapports narratifs IA |
| `ai-chatbot` | Assistant conversationnel |
| `auto-reconcile` | Rapprochement bancaire automatique |
| `exchange-rates` | Taux de change en temps réel |
| `generate-recurring` | Génération factures récurrentes |
| `payment-reminders` | Envoi automatique de relances |
| `send-email` | Envoi d'emails (factures, relances) |
| `api-v1` | API REST publique CashPilot |
| `gocardless-auth` | Connexion Open Banking |
| `webhooks` | Gestion des webhooks |

---

## 🇧🇪 Conformité Belgique

- Plan Comptable Belge (PCB) — 1486+ comptes
- TVA: 21% / 12% / 6% / 0%
- Délais B2B: 30 jours (max 60 jours légal)
- Intérêts de retard: Taux BCE + 8pts
- Indemnité forfaitaire: 40€
- Export FEC et SAF-T
- Factur-X EN16931

---

## 📦 Installation

### Via Claude Code
```bash
claude plugin install cashpilot
```

### Via Claude Cowork Desktop
1. Compresser ce dossier en ZIP
2. Claude Desktop → Cowork → Plugins → Upload ZIP

### Via GitHub (si publié)
```bash
claude plugin marketplace add votre-org/cashpilot-plugin
claude plugin install cashpilot@marketplace
```

---

*Plugin créé le 18 février 2026 — CashPilot v1.0 — Supabase eu-central-1*
