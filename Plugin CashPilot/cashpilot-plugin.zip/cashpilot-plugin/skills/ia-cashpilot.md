# 🤖 Capacités IA de CashPilot

## Edge Functions IA disponibles (Supabase: rfzvrezrcigzmldgvntz)

### 1. `extract-invoice` (verify_jwt: true)
**Usage**: Extraction automatique des données d'une facture fournisseur (PDF/image)
- Extraction: supplier_name, vat_number, iban, montants HT/TVA/TTC, lignes de détail
- Champs renseignés: `ai_extracted`, `ai_confidence`, `ai_raw_response`, `ai_extracted_at`
- Idéal pour automatiser la saisie des factures reçues

### 2. `ai-categorize` (verify_jwt: true)
**Usage**: Catégorisation automatique des dépenses
- Mappe les dépenses sur les catégories et comptes du Plan Comptable Belge
- Utilise l'historique pour améliorer les suggestions

### 3. `ai-anomaly-detect` (verify_jwt: true)
**Usage**: Détection d'anomalies financières
- Transactions inhabituelles par rapport à l'historique
- Doublons potentiels
- Écarts de montants suspects
- Alertes de fraude potentielle

### 4. `ai-forecast` (verify_jwt: true)
**Usage**: Prévisions de trésorerie et revenus
- Projections basées sur les tendances historiques
- Simulation de scénarios (croissance, baisse)
- Alertes de risque de liquidité à venir

### 5. `ai-reminder-suggest` (verify_jwt: true)
**Usage**: Suggestions intelligentes de relances
- Analyse du comportement de paiement par client
- Recommandations de timing et ton des relances
- Priorisation des relances à fort impact

### 6. `ai-report` (verify_jwt: true)
**Usage**: Génération de rapports financiers narratifs
- Synthèse des performances en langage naturel
- Points d'attention et recommandations
- Rapport mensuel / trimestriel / annuel

### 7. `ai-chatbot` (verify_jwt: false)
**Usage**: Assistant conversationnel CashPilot intégré
- Réponses aux questions sur les données financières
- Navigation guidée dans l'application

### 8. `auto-reconcile` (verify_jwt: true)
**Usage**: Rapprochement bancaire automatique
- Matching des transactions bancaires avec les factures
- Confidence score par match
- Gestion des non-matchés

## Données enrichies par IA
Les factures fournisseurs extraites par IA ont une table dédiée:
- `supplier_invoices.ai_confidence` : score de confiance de l'extraction
- Valider toujours les extractions avec confiance < 0.85

## Crédits IA
- Table `user_credits`: free_credits, paid_credits, total_used
- Table `credit_transactions`: historique des transactions (purchase, usage, bonus, refund)
- Table `credit_packages`: packs disponibles à l'achat (via Stripe)

## Application automatique
Quand l'utilisateur demande une analyse IA, une prévision, ou un rapport automatique, propose d'utiliser ces fonctions IA spécialisées de CashPilot.
