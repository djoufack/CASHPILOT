# 📊 Analyse Financière CashPilot

## Modules d'analyse disponibles

### KPIs Tableau de Bord
Via l'outil `get_dashboard_kpis` :
- Revenue facturé ce mois
- Revenue collecté
- Dépenses
- Marge
- Factures en attente (total)

### Statistiques de facturation
Via `get_invoice_stats` :
- Total facturé, payé, impayé, en retard
- Période configurable (défaut: 12 mois)

### Flux de trésorerie
Via `get_cash_flow` :
- Revenus mensuels vs dépenses
- Solde net par mois
- Jusqu'à 12 mois de données

### Top Clients
Via `get_top_clients` :
- Classement par chiffre d'affaires
- Balance client (dû, payé, en retard)

### Balance des créances
Via `get_receivables_summary` :
- Total dû, collecté, en attente, en retard

### Résumé TVA
Via `get_tax_summary` :
- TVA collectée (output) vs TVA déductible (input)
- Solde TVA à déclarer

## Edge Functions d'IA disponibles

### ai-forecast
- Prévisions de trésorerie basées sur les tendances historiques
- Projections des revenus et dépenses
- Alertes de risque de liquidité

### ai-anomaly-detect
- Détection d'anomalies dans les transactions
- Identification de dépenses inhabituelles
- Alertes sur les écarts vs historique

### ai-categorize
- Catégorisation automatique des dépenses
- Mapping avec le plan comptable belge

### ai-reminder-suggest
- Analyse des clients à risque de retard
- Suggestion de stratégie de relance personnalisée

### ai-report
- Génération de rapports financiers narratifs
- Synthèse en langage naturel des données financières

## Scénarios Financiers
Tables: `financial_scenarios`, `scenario_assumptions`, `scenario_results`, `scenario_comparisons`, `scenario_templates`

Types d'hypothèses:
- `growth_rate` — Taux de croissance
- `fixed_amount` — Montant fixe récurrent
- `recurring` — Événement récurrent
- `one_time` — Événement ponctuel
- `percentage_change` — Variation en pourcentage
- `conditional` — Conditionnel

5 templates disponibles pour démarrer rapidement.

## Métriques de performance recommandées
| Métrique | Formule | Seuil d'alerte |
|----------|---------|----------------|
| Marge brute | (CA - Coût des ventes) / CA | < 30% |
| Résultat net | Produits - Charges | Négatif |
| Ratio d'endettement | Dettes / Fonds propres | > 2 |
| BFR | Stocks + Créances - Dettes fournisseurs | Positif élevé |

## Application automatique
Quand l'utilisateur demande une analyse, un rapport ou des prévisions financières, utilise les outils MCP et Edge Functions IA pour fournir des insights basés sur les données réelles.
