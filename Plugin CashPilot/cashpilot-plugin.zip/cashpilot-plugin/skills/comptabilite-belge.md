# 📚 Comptabilité Belge — Plan Comptable & TVA

## Contexte
CashPilot est configuré pour la **Belgique (BE)** avec le Plan Comptable Belge (PCB) initialisé dans Supabase (tables: `accounting_chart_of_accounts`, `accounting_plan_accounts`, `accounting_mappings`).

## Règles TVA Belge
- **TVA standard** : 21% (services, produits courants)
- **TVA réduite** : 6% (denrées alimentaires de base, livres, travaux immobiliers résidentiels, médicaments) et 12% (produits alimentaires restauration, certains logements sociaux)
- **TVA 0%** : exportations hors UE, opérations intracommunautaires avec numéro de TVA valide
- **Exonérations** : prestations médicales, assurances, services financiers
- Le numéro de TVA belge commence par **BE** suivi de 10 chiffres (ex: BE0123456789)
- Déclarations TVA : **mensuelle** si CA > 2,5M€, **trimestrielle** sinon

## Plan Comptable Belge (PCB)
| Classe | Domaine |
|--------|---------|
| 1 | Fonds propres, provisions, dettes à long terme |
| 2 | Actifs immobilisés |
| 3 | Stocks et commandes en cours |
| 4 | Créances et dettes à court terme |
| 5 | Placements de trésorerie et valeurs disponibles |
| 6 | Charges d'exploitation, financières, exceptionnelles |
| 7 | Produits d'exploitation, financiers, exceptionnels |

## Comptes fréquemment utilisés
| Code | Libellé |
|------|---------|
| 400 | Clients |
| 440 | Fournisseurs |
| 451 | TVA à récupérer |
| 451/1 | TVA due |
| 489 | Comptes de régularisation passifs |
| 550 | Institutions financières |
| 600 | Achats de matières premières |
| 700 | Chiffre d'affaires |
| 744 | Subsides en capital |

## Journaux Comptables
- **VE** : Ventes (factures émises)
- **AC** : Achats (factures reçues)
- **BQ** : Banque
- **CA** : Caisse
- **OD** : Opérations diverses

## Exercice Fiscal
- Année civile du 1er janvier au 31 décembre
- Clôture des comptes et dépôt des comptes annuels à la **BCE** dans les 7 mois

## Exports Réglementaires disponibles dans CashPilot
- **FEC** (Fichier des Écritures Comptables) — requis pour contrôles fiscaux
- **SAF-T** (Standard Audit File for Tax) — norme internationale
- **Factur-X** — facture électronique normalisée (profils MINIMUM, BASIC, EN16931)

## Application automatique
Quand l'utilisateur parle de TVA, de comptabilité, de bilan, d'écritures ou de déclarations fiscales, applique toujours les règles belges ci-dessus et utilise les outils MCP CashPilot pour récupérer les données réelles.
