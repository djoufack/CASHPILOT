# 📦 Gestion Stock & Services CashPilot

## Produits (`products`)
Champs clés:
- `product_name`, `sku`, `unit` — Identification
- `unit_price` — Prix de vente HT
- `purchase_price` — Prix d'achat (pour calcul marge)
- `stock_quantity` — Stock actuel
- `min_stock_level` — Seuil de réapprovisionnement
- `supplier_id` — Fournisseur lié
- `is_active` — Actif/inactif
- `category_id` → `product_categories`

### Alertes stock
- `stock_alerts` : low_stock, out_of_stock, overstock
- `product_stock_history` : historique de toutes les mouvements
- `product_barcodes` : codes-barres (EAN, QR, etc.)
- `barcode_scan_logs` : logs de scans

## Services (`services`)
Types de tarification:
- `hourly` — Taux horaire
- `fixed` — Prix forfaitaire
- `per_unit` — Prix à l'unité

Champs:
- `hourly_rate`, `fixed_price`, `unit_price`
- `unit` — Unité (heure, jour, pièce, etc.)
- `category_id` → `service_categories`

## Timesheets (suivi du temps)
Table `timesheets` :
- Lié à: `project_id`, `task_id`, `client_id`, `service_id`
- `duration_minutes` — Durée en minutes
- `billable` — Facturable ou non
- `hourly_rate` — Taux appliqué
- `invoice_id` — Facture associée (si facturé)
- `status` : draft, submitted, approved, invoiced

## Projets & Tâches
### Projets (`projects`)
- `budget_hours` — Budget en heures
- `hourly_rate` — Taux horaire du projet
- `status` : active, paused, completed

### Tâches (`tasks`)
- `estimated_hours` — Heures estimées
- `service_id` — Service associé
- `status` : pending, in_progress, completed
- `subtasks` — Sous-tâches

## Application automatique
Quand l'utilisateur parle de stock, de produits, de services ou de temps passé, utilise ces informations pour contextualiser les réponses et les outils MCP disponibles.
