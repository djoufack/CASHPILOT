# 🧾 Facturation — Meilleures Pratiques CashPilot

## Structure de la Base de Données CashPilot (Supabase: rfzvrezrcigzmldgvntz)

### Tables principales
- **invoices** — Factures (statuts: draft, sent, paid, overdue, cancelled | paiement: unpaid, partial, paid, overpaid)
- **invoice_items** — Lignes de facture (types: product, service, timesheet, manual)
- **quotes** — Devis (draft, sent, accepted, rejected, expired)
- **credit_notes** — Avoirs (draft, issued, applied, cancelled)
- **delivery_notes** — Bons de livraison (pending, shipped, delivered, cancelled)
- **recurring_invoices** — Factures récurrentes (active, paused, completed)
- **payment_reminder_rules** — Règles de relance automatique
- **invoice_settings** — Paramètres de présentation

### Champs importants d'une facture
- `invoice_number` — numéro unique (format recommandé: YYYY-NNNN)
- `total_ht` — montant hors taxes
- `tax_rate` — taux de TVA (défaut: 21 pour Belgique)
- `total_ttc` — montant TTC = total_ht × (1 + tax_rate/100)
- `discount_type` — none / percentage / fixed
- `payment_status` — unpaid / partial / paid / overpaid
- `invoice_type` — product / service / mixed

## Processus de facturation recommandé
1. **Devis** → Créer et envoyer au client → Attendre acceptation
2. **Facture** → Convertir le devis accepté ou créer directement → Statut `draft`
3. **Envoi** → Changer statut en `sent` → Envoyer par email via `send-email` Edge Function
4. **Suivi** → Vérifier les impayés → Lancer relances automatiques
5. **Encaissement** → Enregistrer paiement → Statut `paid`

## Règles de numérotation belge
- Numérotation **séquentielle et sans interruption**
- Format suggéré: `FACT-2026-0001`
- Les numéros ne peuvent pas être réutilisés même après annulation
- En cas d'erreur : émettre un **avoir** (credit note), ne jamais supprimer

## Délais de paiement (droit belge)
- B2B par défaut : **30 jours** de la date de facture
- Maximum légal B2B : **60 jours** (peut être étendu à 360 jours par accord écrit)
- Intérêts de retard légaux : taux BCE + 8 points (env. 12-13%)
- Indemnité forfaitaire : **40€** par facture impayée

## Mentions obligatoires sur une facture belge
1. Numéro de TVA du vendeur (BE XXXXXXXXXX)
2. Date d'émission
3. Numéro séquentiel unique
4. Nom, adresse et n° TVA du client (si assujetti)
5. Description des biens/services
6. Date de livraison ou prestation (si différente de la facture)
7. Base imposable (HT) et taux TVA ou mention d'exonération
8. Montant TVA
9. Coordonnées bancaires (IBAN/BIC)

## Application automatique
Quand l'utilisateur demande de créer une facture, un devis ou un avoir, applique ces règles et utilise les outils MCP CashPilot. Calcule automatiquement TVA à 21% si non précisé.
