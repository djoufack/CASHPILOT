# 👥 Clients & Fournisseurs CashPilot

## Clients (`clients`)
Informations complètes:
- **Coordonnées**: company_name, contact_name, email, phone, website
- **Adresse**: address, city, postal_code, country
- **Financier**: vat_number, tax_id, preferred_currency, payment_terms, iban, bic_swift, bank_name
- **Historique**: créances, factures, devis, timesheets, projets

Relations:
- Un client peut avoir plusieurs projets, factures, devis, avoirs, bons de livraison
- La balance client inclut: total facturé, payé, impayé, en retard

## Fournisseurs (`suppliers`)
Types: `service`, `product`, `both`
Statut: `active`, `inactive`

Informations:
- **Coordonnées**: company_name, contact_person, email, phone
- **Financier**: tax_id, currency, iban, bic_swift, payment_terms
- **Géolocalisation**: `supplier_locations` (latitude, longitude, horaires)

Relations fournisseurs:
- `supplier_products` — Catalogue produits fournisseur
- `supplier_services` — Services proposés
- `supplier_invoices` — Factures reçues (avec extraction IA possible)
- `supplier_orders` — Commandes passées
- `supplier_order_items` — Détail des commandes
- `delivery_routes` — Itinéraires de livraison

## Règles de gestion client belge
- Vérifier le numéro de TVA sur le **portail VIES** (EU) pour les clients UE
- Conserver les coordonnées client 7 ans (obligation comptable)
- RGPD : droit à l'effacement, consentement requis pour marketing

## Profil utilisateur (`profiles`, `company`)
- `company.company_type` : freelance / company
- `company.currency` : ISO 4217 (EUR par défaut en Belgique)
- `profiles.role` : admin, user, freelance, accountant, manager, client

## Application automatique
Quand l'utilisateur mentionne un client ou un fournisseur, utilise les outils MCP pour récupérer ses données complètes incluant sa balance et son historique.
