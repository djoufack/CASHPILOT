# 💵 Gestion de Trésorerie CashPilot

## Vue d'ensemble des flux
CashPilot suit les flux financiers à travers plusieurs tables interconnectées :

### Entrées de trésorerie
- **payments** — Encaissements clients (méthodes: cash, bank_transfer, check, card, paypal, other)
- **payment_allocations** — Allocation d'un paiement sur plusieurs factures
- **bank_transactions** — Transactions importées via GoCardless (Open Banking)

### Sorties de trésorerie
- **expenses** — Dépenses/frais (refacturables ou non)
- **supplier_invoices** — Factures fournisseurs (pending, paid, overdue)
- **payables** — Dettes personnelles/informelles

### Créances & Dettes informelles
- **receivables** — Argent prêté (pending, partial, paid, overdue)
- **payables** — Argent emprunté (pending, partial, paid, overdue)
- **debt_payments** — Paiements de dettes/créances

## Rapprochement Bancaire
CashPilot dispose d'un système de rapprochement automatique:
- Import de relevés bancaires (PDF, XLSX, XLS, CSV) → `bank_statements` + `bank_statement_lines`
- Connexion directe Open Banking via **GoCardless** → `bank_connections`
- Rapprochement auto/manuel → `bank_reconciliation_sessions`
- Statuts de rapprochement: `unmatched`, `matched`, `ignored`

## Connexions Bancaires (GoCardless)
- Accès aux comptes belges : BNP Paribas Fortis, ING, KBC, Belfius, Bpost Bank, etc.
- Synchronisation automatique des transactions
- Matching automatique avec les factures émises

## Indicateurs clés à surveiller
| KPI | Description | Objectif |
|-----|-------------|----------|
| DSO (Days Sales Outstanding) | Délai moyen d'encaissement | < 45 jours |
| Cash burn rate | Vitesse de consommation des liquidités | Positif |
| Current ratio | Actifs courants / Passifs courants | > 1,2 |
| Taux de recouvrement | Factures payées vs émises | > 95% |

## Alertes importantes
- Factures impayées > 30 jours → relance automatique
- Factures impayées > 60 jours → relance urgente + intérêts légaux
- Stock sous le niveau minimum → alerte réapprovisionnement
- Solde bancaire prévu < 0 → alerte trésorerie (via ai-forecast)

## Application automatique
Quand l'utilisateur parle de trésorerie, de flux de paiement, de rapprochement ou d'impayés, utilise les outils MCP pour récupérer les données réelles et fournir des analyses concrètes.
