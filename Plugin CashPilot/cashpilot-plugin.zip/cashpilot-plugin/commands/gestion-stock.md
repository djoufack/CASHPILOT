# /cashpilot:gestion-stock

Gère le catalogue produits, les niveaux de stock et les alertes.

## Déclencheurs
- "stock", "inventaire", "produits", "réapprovisionnement", "catalogue", "niveaux de stock"

## Instructions

### Vue d'ensemble du stock
1. Récupérer tous les produits actifs (`products`)
2. Identifier les alertes actives (`stock_alerts`)
3. Récupérer l'historique des mouvements récents (`product_stock_history`)

### Affichage

```
📦 ÉTAT DU STOCK — [Date]
━━━━━━━━━━━━━━━━━━━━━━

🔴 EN RUPTURE (stock = 0):
[Liste des produits]

🟠 STOCK FAIBLE (< min_stock_level):
[Liste avec stock actuel vs minimum]

🟢 STOCK NORMAL:
[Résumé par catégorie]
```

### Analyse de stock
Pour chaque produit en alerte:
- Nom, SKU, stock actuel
- Niveau minimum configuré
- Fournisseur associé
- Prix d'achat / Prix de vente / Marge
- Dernière date de mouvement

### Actions disponibles
1. **Créer une commande fournisseur** — Initier un réapprovisionnement
2. **Ajuster le stock** — Correction manuelle (inventaire physique)
3. **Modifier le seuil** — Mettre à jour min_stock_level
4. **Activer/désactiver** — Gérer is_active

### Valorisation du stock
Calcule automatiquement:
- Valeur totale au prix d'achat = Σ (stock × purchase_price)
- Valeur totale au prix de vente = Σ (stock × unit_price)
- Marge potentielle totale

### Commandes en cours
Vérifie les `supplier_orders` avec statut pending/confirmed/shipped pour anticiper les entrées de stock.
