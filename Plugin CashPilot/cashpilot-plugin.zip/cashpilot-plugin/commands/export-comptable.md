# /cashpilot:export-comptable

Exporte les données comptables aux formats réglementaires.

## Déclencheurs
- "export comptable", "FEC", "SAF-T", "Factur-X", "export fiscal", "déclaration TVA", "fichier comptable"

## Instructions

### Choisir le format d'export

**1. FEC — Fichier des Écritures Comptables**
- Requis pour les contrôles fiscaux en France/Belgique
- Utilise `export_fec` avec start_date et end_date
- Format: texte délimité (pipe |), encodage UTF-8
- Contient toutes les écritures du journal

**2. SAF-T — Standard Audit File for Tax**
- Norme internationale ISO 20022
- Utilise `export_saft` avec start_date et end_date
- Format XML structuré
- Utilisé en Belgique pour les audits fiscaux

**3. Factur-X — Facture électronique normalisée**
- Standard européen EN 16931
- Utilise `export_facturx` avec invoice_id et profile
- Profils disponibles:
  - `MINIMUM` — Données minimales obligatoires
  - `BASIC` — Données de base (recommandé)
  - `EN16931` — Conformité totale EN 16931

### Collecter les paramètres

Pour FEC et SAF-T:
- **Période de début** (ex: 2026-01-01)
- **Période de fin** (ex: 2026-12-31)

Pour Factur-X:
- **Numéro de facture** ou ID de facture
- **Profil** (BASIC recommandé)

### Calendrier fiscal belge (rappels)
| Déclaration | Fréquence | Délai |
|-------------|-----------|-------|
| TVA mensuelle | Mensuelle | 20 du mois suivant |
| TVA trimestrielle | Trimestrielle | 20 du mois suivant le trimestre |
| Listing TVA annuel | Annuel | 31 mars |
| IPP / ISOC | Annuel | Variable |
| Comptes annuels | Annuel | 7 mois après clôture |

### Après l'export
Vérifie que:
- La balance est équilibrée (Total D = Total C)
- Toutes les écritures ont une référence
- Les périodes sont continues (pas de trous)
- Les numéros de pièces sont séquentiels
