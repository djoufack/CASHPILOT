# /cashpilot:fournisseurs

Gère les fournisseurs, leurs factures et commandes.

## Déclencheurs
- "fournisseurs", "facture fournisseur", "commande fournisseur", "achats", "dépenses fournisseur"

## Instructions

### Vue d'ensemble des fournisseurs
Liste les fournisseurs actifs avec:
- Nombre de factures en attente de paiement
- Montant total dû
- Prochaine échéance

### Factures fournisseurs (`supplier_invoices`)
Pour chaque facture:
- Numéro, fournisseur, montant HT/TVA/TTC
- Statut: pending, paid, overdue, cancelled
- Date d'échéance
- Extraction IA: ai_extracted, ai_confidence

**Workflow d'import d'une nouvelle facture fournisseur:**
1. Upload du PDF → Edge Function `extract-invoice`
2. Vérification des données extraites (confiance < 0.85 → validation manuelle)
3. Validation et enregistrement dans `supplier_invoices`
4. Comptabilisation automatique via les mappings comptables

### Commandes fournisseurs (`supplier_orders`)
Statuts: pending → confirmed → shipped → delivered → cancelled
- Suivi des livraisons avec dates estimées/réelles
- Itinéraires de livraison (`delivery_routes`)
- Mise à jour automatique du stock à la livraison

### Analyse des achats
- Dépenses par fournisseur sur 12 mois
- Top 5 fournisseurs par volume
- Délais de paiement moyens
- Comparaison prix vs catalogue (`supplier_products`)

### TVA récupérable
Calcule la TVA déductible sur les factures fournisseurs:
- TVA input = Σ vat_amount des factures payées
- Déduire de la TVA output pour la déclaration

### Paiement fournisseur
Pour les factures en attente:
- Propose l'ordre de priorité (par échéance)
- Calcule le montant total à décaisser
- Vérifie la disponibilité de trésorerie
