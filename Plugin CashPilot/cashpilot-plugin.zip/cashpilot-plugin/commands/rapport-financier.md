# /cashpilot:rapport-financier

Génère un rapport financier complet pour une période donnée.

## Déclencheurs
- "rapport financier", "rapport mensuel", "bilan mensuel", "performance financière", "résultats du mois"

## Instructions

### Étape 1 — Définir la période
Demande si nécessaire:
- **Mois/période** (défaut: mois en cours)
- **Type de rapport**: mensuel, trimestriel, annuel, personnalisé

### Étape 2 — Collecter les données

1. `get_dashboard_kpis` — KPIs principaux
2. `get_cash_flow` — Flux de trésorerie (6 mois pour contexte)
3. `get_invoice_stats` — Stats de facturation (12 mois)
4. `get_top_clients` — Top 10 clients par CA
5. `get_receivables_summary` — Balance des créances
6. `get_tax_summary` — Résumé TVA (avec dates de la période)
7. `get_accounting_entries` — Journal comptable si disponible

### Étape 3 — Structure du rapport

```
📊 RAPPORT FINANCIER — [Période]
━━━━━━━━━━━━━━━━━━━━━━━━━━

1. RÉSUMÉ EXÉCUTIF
   ↗ CA facturé: [montant] (vs période précédente: ±%)
   ↗ CA encaissé: [montant]
   ↘ Dépenses: [montant]
   ═ Marge nette: [montant] ([%])

2. FACTURATION
   • Factures émises: [nb] pour [montant HT]
   • Factures payées: [nb] — [%] du total
   • En attente: [nb] pour [montant]
   • En retard: [nb] pour [montant] ⚠️

3. TRÉSORERIE
   [Tableau mensuel entrées / sorties / solde]

4. TVA
   • TVA collectée: [montant]
   • TVA déductible: [montant]  
   • Solde à déclarer: [montant]

5. TOP CLIENTS
   [Tableau top 5 clients avec CA et statut]

6. ANALYSE & RECOMMANDATIONS
   [Insights basés sur les données]
   [Points d'attention]
   [Actions recommandées]
```

### Étape 4 — Sauvegarder si demandé
Propose d'exporter en XLSX ou PDF via les outils disponibles.
