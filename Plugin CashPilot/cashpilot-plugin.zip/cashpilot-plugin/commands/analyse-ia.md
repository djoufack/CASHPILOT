# /cashpilot:analyse-ia

Lance une analyse intelligente des données financières via les modules IA de CashPilot.

## Déclencheurs
- "analyse IA", "prévisions", "anomalies", "intelligence artificielle", "forecast", "prédictions"

## Instructions

### Menu d'analyse
Propose à l'utilisateur de choisir:

**1. 🔮 Prévisions de trésorerie** (`ai-forecast`)
- Projection sur 3, 6 ou 12 mois
- Basée sur l'historique des revenus et dépenses
- Alertes de risque de liquidité
- Scénarios optimiste/pessimiste

**2. 🔍 Détection d'anomalies** (`ai-anomaly-detect`)
- Transactions inhabituelles
- Doublons potentiels
- Comportements de paiement anormaux
- Alertes de fraude potentielle

**3. 🏷️ Catégorisation automatique** (`ai-categorize`)
- Catégoriser les dépenses non classifiées
- Mapping automatique avec le PCB belge
- Suggestions de comptes comptables

**4. 📬 Optimisation des relances** (`ai-reminder-suggest`)
- Analyse du comportement de paiement par client
- Score de risque par client
- Timing optimal pour les relances
- Personnalisation du message

**5. 📝 Rapport narratif** (`ai-report`)
- Synthèse en langage naturel
- Points positifs et axes d'amélioration
- Recommandations stratégiques
- Comparaison vs période précédente

**6. 📄 Extraction facture fournisseur** (`extract-invoice`)
- Upload d'une facture PDF/image
- Extraction automatique de toutes les données
- Vérification et validation des montants
- Import dans CashPilot

### Après l'analyse
Présente les résultats de manière structurée avec:
- Score de confiance pour les prédictions
- Actions recommandées classées par priorité
- Option de sauvegarder les résultats
