# /cashpilot:scenario-financier

Crée et analyse des scénarios de simulation financière.

## Déclencheurs
- "scénario financier", "simulation", "prévision", "que se passerait-il si", "projection", "hypothèse"

## Instructions

### Qu'est-ce qu'un scénario ?
Un scénario financier permet de simuler l'impact d'hypothèses sur les finances futures:
- "Si je recrute un employé en mars, quel impact sur ma trésorerie ?"
- "Si mon CA augmente de 20%, quelle sera ma TVA ?"
- "Simulation de croissance sur 12 mois"

### Templates disponibles
CashPilot propose 5 templates pré-configurés (`scenario_templates`):
1. 📈 Croissance du CA
2. 📉 Scénario de récession
3. 🏗️ Lancement d'un nouveau service
4. 👥 Recrutement
5. 💡 Investissement matériel

### Créer un nouveau scénario

**Collecter:**
- Nom du scénario
- Description
- Date de début / Date de fin
- Utiliser un template ou partir de zéro

**Types d'hypothèses (`scenario_assumptions`):**
| Type | Exemple |
|------|---------|
| `growth_rate` | CA +15% par mois |
| `fixed_amount` | +5000€/mois de charges |
| `recurring` | Loyer 1200€/mois |
| `one_time` | Achat équipement 15000€ |
| `percentage_change` | Dépenses -10% |
| `conditional` | Si CA > 50k alors embauche |

### Analyser un scénario existant
1. Lister les scénarios disponibles
2. Afficher les hypothèses configurées
3. Présenter les résultats (`scenario_results`) par période:
   ```
   📊 RÉSULTATS DU SCÉNARIO: [Nom]
   ━━━━━━━━━━━━━━━━━━━━━━━━
   Période     | CA projeté | Charges | Trésorerie
   Janvier     | [montant]  | [...]   | [...]
   Février     | [...]      | [...]   | [...]
   ```

### Comparaison de scénarios
Via `scenario_comparisons` : compare plusieurs scénarios côte à côte pour choisir la meilleure stratégie.

**Exemple:**
```
COMPARAISON: Croissance rapide vs Croissance prudente
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Métrique          | Rapide    | Prudent
CA à 12 mois      | +45%      | +20%
Trésorerie min    | -5000€ ⚠️  | +8000€ ✅
Risque            | Élevé     | Faible
```
