# /cashpilot:encaisser-paiement

Enregistre l'encaissement d'un paiement client.

## Déclencheurs
- "encaisser", "enregistrer un paiement", "marquer comme payé", "réglé", "paiement reçu"

## Instructions

### Étape 1 — Identifier la facture
1. Si l'utilisateur mentionne un numéro de facture: utilise `search_invoices` avec le numéro
2. Si l'utilisateur mentionne un client: utilise `list_invoices` filtré par client
3. Si aucune info: utilise `get_unpaid_invoices` pour lister les impayées

### Étape 2 — Vérifier la facture
Utilise `get_invoice` pour récupérer:
- Montant total TTC (`total_ttc`)
- Balance due (`balance_due`)
- Statut de paiement actuel
- Client associé

### Étape 3 — Collecter les informations de paiement
- **Montant encaissé** (défaut: balance_due complète)
- **Mode de paiement**: bank_transfer / cash / check / card / paypal / other
- **Date** (défaut: aujourd'hui)
- **Référence** (numéro de virement, chèque, etc.)
- **Notes** éventuelles

### Étape 4 — Enregistrer le paiement
Utilise `create_payment` avec toutes les informations.
Le statut de paiement de la facture se met à jour automatiquement:
- Paiement complet → `paid`
- Paiement partiel → `partial`

### Étape 5 — Confirmer
Affiche:
- ✅ Paiement enregistré: [montant] [devise]
- 📄 Facture [numéro]: statut → [nouveau statut]
- 💰 Balance restante: [montant ou 0]

Si la facture est entièrement réglée, félicite et propose d'envoyer un reçu.
