# /cashpilot:rapprochement-bancaire

Réalise le rapprochement entre les transactions bancaires et les factures CashPilot.

## Déclencheurs
- "rapprochement bancaire", "réconciliation", "transactions bancaires", "relevé bancaire", "rapprocher"

## Instructions

### Option A — Import de relevé bancaire
Si l'utilisateur a un fichier (PDF, XLSX, CSV):
1. Importer via le module d'import de `bank_statements`
2. Parser les lignes → `bank_statement_lines`
3. Lancer le rapprochement automatique via `auto-reconcile`
4. Présenter les lignes non rapprochées pour traitement manuel

### Option B — Open Banking (GoCardless)
Si une connexion bancaire existe (`bank_connections`):
1. Récupérer les nouvelles transactions (`bank_transactions`)
2. Lancer le rapprochement auto
3. Valider les matches à haute confiance
4. Traiter les exceptions

### Statuts de rapprochement
- `matched` — Rapproché automatiquement (montant + référence concordants)
- `unmatched` — Non rapproché (traitement manuel requis)
- `ignored` — Ignoré volontairement (virement interne, etc.)

### Workflow de traitement manuel
Pour chaque ligne `unmatched`:
1. Afficher la transaction bancaire (date, montant, libellé)
2. Rechercher dans les factures/dépenses correspondantes
3. Proposer des matches potentiels basés sur montant ±5% et date ±15 jours
4. Demander confirmation
5. Marquer comme `matched` ou `ignored`

### Résumé du rapprochement
Affiche la session (`bank_reconciliation_sessions`):
```
📊 RAPPROCHEMENT BANCAIRE — [Période]
━━━━━━━━━━━━━━━━━━━━━━━━
✅ Lignes rapprochées: [nb] / [total] ([%])
⚠️  Non rapprochées: [nb]
🚫 Ignorées: [nb]
━━━━━━━━━━━━━━━━━━━━━━━━
💰 Crédits rapprochés: [montant]
💸 Débits rapprochés: [montant]
❗ Différence résiduelle: [montant]
```

### Bonnes pratiques
- Rapprocher mensuellement avant la déclaration TVA
- Les lignes non rapprochées > 60 jours nécessitent investigation
- Conserver les preuves pour audit comptable
