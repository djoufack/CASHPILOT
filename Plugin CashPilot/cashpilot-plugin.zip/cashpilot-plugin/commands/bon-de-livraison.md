# /cashpilot:bon-de-livraison

Crée et suit les bons de livraison associés aux factures.

## Déclencheurs
- "bon de livraison", "expédition", "livraison", "suivi colis", "BL", "bon d'expédition"

## Instructions

### Qu'est-ce qu'un bon de livraison ?
Document qui accompagne la marchandise lors de la livraison. Il décrit ce qui est livré (sans les prix). Distinct de la facture mais peut y être associé.

### Étape 1 — Informations du bon de livraison
Collecte:
- **Client** (`client_id`) — via `list_clients`
- **Facture associée** (`invoice_id`) — optionnel, lie au document de facturation
- **Date de livraison** (`date`) — aujourd'hui par défaut
- **Adresse de livraison** (`delivery_address`)
- **Transporteur** (`carrier`) — ex: DHL, bpost, DPD, livraison propre...
- **Numéro de suivi** (`tracking_number`)
- **Lignes** (`delivery_note_items`): description, quantité, unité

### Étape 2 — Créer le bon
Format du numéro recommandé: `BL-YYYY-NNNN`

Statuts disponibles:
| Statut | Description |
|--------|-------------|
| `pending` | Préparé, pas encore expédié |
| `shipped` | En cours d'acheminement |
| `delivered` | Livré et confirmé |
| `cancelled` | Annulé |

### Étape 3 — Workflow de suivi

```
📦 BON DE LIVRAISON [numéro]
Client: [nom]
Date: [date]
Statut: [statut]
Transporteur: [carrier] — Tracking: [numéro]

Articles livrés:
• [description] × [quantité] [unité]
• ...
```

### Lien avec la facturation
- Un bon de livraison peut être créé **avant** la facture (livraison partielle)
- Ou associé à une facture existante pour confirmer la livraison
- Plusieurs bons de livraison peuvent être liés à une même facture (livraisons échelonnées)

### Mise à jour du statut
Quand la livraison est confirmée:
1. Mettre à jour le statut → `delivered`
2. Si la facture associée est en statut `draft`, proposer de la passer en `sent`
3. Mettre à jour les quantités en stock si c'est une livraison fournisseur
