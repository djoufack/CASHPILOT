# /cashpilot:creer-facture

Crée une nouvelle facture pour un client.

## Déclencheurs
- "créer une facture", "nouvelle facture", "facturer", "émettre une facture"

## Instructions

### Étape 1 — Collecter les informations
Si l'utilisateur n'a pas fourni toutes les informations, demande:
1. **Nom du client** (cherche dans `list_clients` si déjà existant)
2. **Lignes de facturation** : description, quantité, prix unitaire HT
3. **Taux de TVA** (défaut: 21% Belgique)
4. **Date d'échéance** (défaut: +30 jours, recommandation belge)
5. **Remise éventuelle** (type: none/percentage/fixed)
6. **Notes** ou conditions particulières

### Étape 2 — Vérifier le client
Utilise `list_clients` avec search=[nom] pour trouver un client existant.
Si non trouvé, propose de le créer avec `create_client` avant de continuer.

### Étape 3 — Calculer les montants
```
total_ht = Σ (quantité × prix_unitaire - remise)
tax_amount = total_ht × (tax_rate / 100)
total_ttc = total_ht + tax_amount
```

### Étape 4 — Créer la facture
Utilise `create_invoice` avec:
- `client_id` : ID du client trouvé/créé
- `invoice_number` : format recommandé FACT-YYYY-NNNN (vérifie le dernier numéro)
- `date` : aujourd'hui (YYYY-MM-DD)
- `due_date` : +30 jours par défaut
- `total_ht`, `tax_rate`, `total_ttc`
- `status` : "draft" par défaut
- `notes` : conditions de paiement, IBAN, etc.

### Étape 5 — Confirmer et proposer la suite
Affiche le récapitulatif de la facture créée et propose:
- [ ] Envoyer par email au client
- [ ] Marquer comme "envoyée"
- [ ] Télécharger en PDF

## Mentions légales automatiques (Belgique)
Rappelle à l'utilisateur d'inclure dans les notes:
- Numéro de TVA vendeur et acheteur
- Coordonnées bancaires (IBAN/BIC)
- Conditions de paiement et pénalités de retard
