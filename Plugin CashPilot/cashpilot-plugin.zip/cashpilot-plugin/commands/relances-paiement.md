# /cashpilot:relances-paiement

Analyse les impayés et génère des relances clients.

## Déclencheurs
- "relances", "impayés", "factures en retard", "clients qui ne paient pas", "recouvrement"

## Instructions

### Étape 1 — Récupérer les impayés
Utilise `get_unpaid_invoices` pour lister toutes les factures impayées.
Puis `get_unpaid_invoices` avec days_overdue=30 pour identifier les plus urgentes.

### Étape 2 — Analyser et classer
Classe les impayés par urgence:
- 🔴 **URGENT** : > 60 jours de retard — action juridique possible
- 🟠 **ALERTE** : 31–60 jours — 3e relance + mise en demeure
- 🟡 **ATTENTION** : 8–30 jours — 2e relance ferme
- 🟢 **RÉCENT** : 1–7 jours — 1ère relance courtoise

### Étape 3 — Générer les relances

Pour chaque facture impayée, génère un email de relance adapté au niveau:

**Niveau 1 (courtois):**
```
Objet: Rappel - Facture [NUMÉRO] en attente de règlement
Ton: Poli, possibilité d'oubli, proposition d'aide
```

**Niveau 2 (ferme):**
```
Objet: 2ème relance - Facture [NUMÉRO] impayée - Échéance dépassée
Ton: Ferme, rappel des conséquences, délai de paiement imposé
```

**Niveau 3 (mise en demeure):**
```
Objet: MISE EN DEMEURE - Facture [NUMÉRO] - [MONTANT]€
Ton: Formel, mention des intérêts de retard (taux légal belge), 
     indemnité forfaitaire 40€, délai de 8 jours
```

### Étape 4 — Calcul des intérêts (Belgique)
Pour les retards > 30 jours en B2B:
- Intérêts légaux: Taux BCE + 8 points (≈ 12-13%)
- Formule: Montant × Taux × (Jours de retard / 365)
- Indemnité forfaitaire minimale: **40€** par facture

### Étape 5 — Résumé
Présente:
- Total des impayés par niveau d'urgence
- Montant total à recouvrer
- Actions recommandées par priorité
- Proposition de mise à jour des statuts via `update_invoice_status`
