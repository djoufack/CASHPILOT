# /cashpilot:note-de-credit

Crée un avoir (note de crédit) pour annuler ou corriger une facture.

## Déclencheurs
- "avoir", "note de crédit", "annuler une facture", "remboursement", "rectification facture", "credit note"

## Instructions

### Pourquoi un avoir ?
En Belgique, il est **interdit** de supprimer ou modifier une facture envoyée.
Pour corriger une erreur ou rembourser: émettre un **avoir** qui annule partiellement ou totalement la facture d'origine.

### Étape 1 — Identifier la facture d'origine
1. Demande le numéro de facture à corriger
2. Utilise `search_invoices` pour la retrouver
3. Vérifie le statut (sent, paid, overdue)
4. Affiche le détail de la facture

### Étape 2 — Type d'avoir
- **Avoir total**: annule toute la facture
- **Avoir partiel**: annule seulement certaines lignes ou un montant spécifique

### Étape 3 — Informations de l'avoir
Collecte:
- `credit_note_number` — Format: AVOIR-YYYY-NNNN
- `date` — Date de l'avoir (aujourd'hui)
- `reason` — Motif: erreur de prix, produit défectueux, retour marchandise, remise commerciale...
- Lignes de l'avoir (`credit_note_items`): description, quantité, prix unitaire
- `status` — draft par défaut

### Étape 4 — Calcul des montants
```
total_ht = Σ lignes
tax_amount = total_ht × (tax_rate / 100)
total_ttc = total_ht + tax_amount
```
⚠️ Le montant de l'avoir ne peut pas dépasser le montant de la facture d'origine.

### Statuts de l'avoir
| Statut | Description |
|--------|-------------|
| `draft` | En préparation |
| `issued` | Émis et envoyé au client |
| `applied` | Appliqué sur une nouvelle facture |
| `cancelled` | Annulé |

### Après création
Propose:
- Envoyer l'avoir par email au client
- Imputer l'avoir sur une nouvelle facture
- Rembourser en espèces/virement (enregistrer le paiement sortant)

### Mention légale obligatoire
L'avoir doit mentionner:
- Le numéro de la facture d'origine
- Le motif de l'avoir
- La date de l'opération initiale
