# /cashpilot:creer-devis

Crée un devis professionnel pour un client.

## Déclencheurs
- "créer un devis", "nouveau devis", "offre de prix", "proposition commerciale", "établir un devis"

## Instructions

### Étape 1 — Informations du devis
Collecte:
1. **Client** (existant via `list_clients` ou nouveau)
2. **Prestations/produits** : description, quantité, prix HT
3. **Validité du devis** (recommandé: 30 jours)
4. **Remise commerciale** éventuelle
5. **Conditions particulières**

### Étape 2 — Créer le devis
Utilise `create_invoice` avec:
- Type document : quote (utilise le statut "draft")
- `quote_number` : format DEVIS-YYYY-NNNN
- Calcul TVA 21% standard sauf exception

### Étape 3 — Suivi du devis
Après création, explique le workflow:
1. **draft** → En préparation
2. **sent** → Envoyé au client
3. **accepted** → Accepté → Convertir en facture
4. **rejected** → Refusé
5. **expired** → Délai de validité dépassé

## Bonnes pratiques devis belge
- Validité recommandée : 30 jours
- Inclure les conditions de paiement dès le devis
- Préciser si les prix sont HT ou TTC
- Mentionner la politique d'acompte si applicable
- Signer électroniquement si possible (valeur juridique)
