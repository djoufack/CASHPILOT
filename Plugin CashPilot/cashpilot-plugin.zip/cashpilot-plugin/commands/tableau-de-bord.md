# /cashpilot:tableau-de-bord

Affiche un tableau de bord financier complet et synthétique.

## Déclencheurs
- "tableau de bord", "dashboard", "vue d'ensemble", "résumé financier", "KPIs", "situation financière"

## Instructions

Récupère et présente dans cet ordre:

### 1. KPIs du mois en cours
Utilise `get_dashboard_kpis` pour obtenir:
- Revenue facturé ce mois
- Revenue collecté
- Dépenses
- Marge (%)
- Factures en attente

### 2. Flux de trésorerie (6 derniers mois)
Utilise `get_cash_flow` avec months=6 pour le graphique mensuel.

### 3. Factures impayées urgentes
Utilise `get_unpaid_invoices` avec days_overdue=0 pour lister les impayés.

### 4. Top 5 clients
Utilise `get_top_clients` avec limit=5.

### 5. Statistiques de facturation (12 mois)
Utilise `get_invoice_stats` avec months=12.

## Format de sortie

Présente les données sous forme de tableau de bord structuré avec:
- 📈 **Revenus** : [montant facturé] / [montant encaissé]
- 💸 **Dépenses** : [montant]
- 📊 **Marge** : [%]
- ⚠️ **Impayés** : [nombre] factures pour [montant total]
- 🏆 **Top client** : [nom] — [CA]

Ensuite le flux de trésorerie mensuel en tableau.
Ensuite les factures en retard triées par ancienneté.

Si des anomalies sont détectées (impayés importants, marge négative, baisse de CA), mets-les en évidence avec des recommandations concrètes.
