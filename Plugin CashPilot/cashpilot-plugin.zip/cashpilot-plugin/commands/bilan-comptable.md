# /cashpilot:bilan-comptable

Affiche la balance comptable et les états financiers.

## Déclencheurs
- "bilan comptable", "balance de vérification", "grand livre", "état financier", "compte de résultat", "plan comptable"

## Instructions

### Étape 1 — Choisir le type d'état

**1. Balance de vérification** (`get_trial_balance`)
- Soldes débiteurs et créditeurs par compte
- Date de référence configurable
- Vérification de l'équilibre D = C

**2. Grand livre** (`get_accounting_entries`)
- Toutes les écritures par compte
- Filtrable par code de compte et période
- Format journal belge (VE, AC, BQ, CA, OD)

**3. Résumé par catégorie** (`get_chart_of_accounts`)
- Plan comptable actif
- Filtrable par: asset, liability, equity, revenue, expense

**4. Résumé TVA** (`get_tax_summary`)
- TVA collectée vs TVA déductible
- Solde net à déclarer

### Étape 2 — Présenter les résultats

Pour la **balance de vérification**:
```
BALANCE DE VÉRIFICATION au [date]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Code | Libellé            | Débit    | Crédit
-----|--------------------|-----------|---------
400  | Clients            | [montant] | -
440  | Fournisseurs       | -        | [montant]
550  | Banque             | [montant] | -
700  | Chiffre d'affaires | -        | [montant]
...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TOTAL                  | [total D] | [total C]
Balance: [✅ Équilibrée / ❌ Déséquilibrée: écart]
```

### Étape 3 — Initialisation si vide
Si la comptabilité n'est pas initialisée:
- Propose d'initialiser pour la Belgique (BE)
- Explique que cela charge le Plan Comptable Belge complet (1486 comptes)
- La table `user_accounting_settings` doit avoir `is_initialized = true`

### Exports disponibles
- **FEC** (Fichier des Écritures Comptables) via `export_fec`
- **SAF-T** via `export_saft`
- Pour une période: fournir start_date et end_date
