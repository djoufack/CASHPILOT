# /cashpilot:suivi-projets

Suivi de l'avancement, des heures et de la rentabilité des projets.

## Déclencheurs
- "projets", "suivi de projet", "heures travaillées", "timesheet", "tâches", "rentabilité projet"

## Instructions

### Vue d'ensemble des projets
Récupère tous les projets actifs depuis la base CashPilot.

Pour chaque projet, affiche:
```
📁 [Nom du projet] — [Client]
   Statut: [active/paused/completed]
   Budget: [budget_hours]h × [hourly_rate]€ = [budget_total]€
   Heures utilisées: [total timesheets] h ([%] du budget)
   Marge restante: [heures restantes]h / [budget restant]€
   Tâches: [X complétées / Y total]
```

### Analyse des timesheets
Pour un projet spécifique:
1. Regrouper les timesheets par tâche et par personne
2. Calculer le total des heures facturables vs non facturables
3. Valeur des heures non encore facturées = heures billable × hourly_rate
4. Proposer de créer une facture pour les heures non facturées

### Alertes dépassement de budget
Si `total_heures_utilisées > budget_hours × 0.8`:
⚠️ **ALERTE**: Le projet utilise > 80% du budget d'heures

### Facturation des heures
Pour les timesheets avec `billable = true` et `invoice_id = null`:
- Calcule le montant facturable
- Propose de créer une facture groupée

### Gestion des tâches
Pour un projet sélectionné:
- Liste des tâches par statut (pending, in_progress, completed)
- Sous-tâches associées
- Service lié et taux horaire
- Heures estimées vs réelles
