# /cashpilot:creer-client

Crée une nouvelle fiche client complète.

## Déclencheurs
- "nouveau client", "ajouter un client", "créer un client", "enregistrer un client"

## Instructions

### Informations à collecter
**Obligatoire:**
- `company_name` — Raison sociale ou nom

**Recommandé:**
- `contact_name` — Nom du contact principal
- `email` — Email de facturation
- `phone` — Téléphone
- `address` / `city` / `postal_code` / `country`
- `vat_number` — Numéro de TVA (format: BE + 10 chiffres pour Belgique)

**Financier:**
- `payment_terms` — Délai de paiement préféré (ex: "30 jours")
- `preferred_currency` — Devise (EUR par défaut)
- `iban` / `bic_swift` / `bank_name`

**Optionnel:**
- `website`
- `notes` — Informations internes

### Validation numéro TVA belge
Si le client est en Belgique:
- Format: BE + 10 chiffres
- Vérifier via VIES : https://ec.europa.eu/taxation_customs/vies/

### Créer le client
Utilise `create_client` avec toutes les informations collectées.

### Après création
Affiche la fiche créée et propose:
- Créer immédiatement une facture pour ce client
- Créer un devis
- Enregistrer un paiement en attente
